You can obtain libxml2 and dependent windows binaries from the project maintainer: 
http://www.zlatkovic.com/libxml.en.html
ftp://ftp.zlatkovic.com/libxml/c